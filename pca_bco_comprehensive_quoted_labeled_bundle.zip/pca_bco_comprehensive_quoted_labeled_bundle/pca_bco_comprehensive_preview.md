# PCA BCO Comprehensive Supplemental Cards — Quotation/Paraphrase Labeled

This preview labels every answer as either **Direct quotation** plus **Paraphrase**, or **Paraphrase** only. Direct quotations are intentionally sparse and very short; longer concepts are paraphrased with BCO references.

## BCO Foundations: Christ, Church Power & the Visible Church

### bco-comp-001. What is the governing theme of the BCO preface?

Direct quotation: “only Lawgiver in Zion.”  
Paraphrase: Christ is the only King and Head of the Church. The church’s doctrine, government, discipline, and worship are received from Him by Scripture, not invented by church courts.

**Refs:** BCO Preface I

**Summary:** Christ rules His church by Word and Spirit; all church order is subordinate to Scripture.

### bco-comp-002. What does the BCO mean by saying church power is “ministerial and declarative”?

Direct quotation: “ministerial and declarative.”  
Paraphrase: Church courts minister and declare what Christ has revealed in Scripture. They do not create new divine law or bind the conscience apart from the Word.

**Refs:** BCO Preface II.7, BCO 11-2

**Summary:** Church courts apply Scripture; they do not legislate for the conscience.

### bco-comp-003. Summarize the PCA Constitution.

Paraphrase: The PCA Constitution is subordinate to Scripture and consists of the Westminster Confession of Faith, Larger and Shorter Catechisms, and the BCO: Form of Government, Rules of Discipline, and Directory for Worship.

**Refs:** BCO Preface III

**Summary:** Scripture is supreme; the Constitution contains the Standards and BCO.

### bco-comp-004. What five heads summarize Presbyterian church government in BCO 1?

Paraphrase: The church, its members, its officers, its courts, and its orders.

**Refs:** BCO 1-1

**Summary:** Five heads: church, members, officers, courts, orders.

### bco-comp-005. How does BCO 1 describe the visible church?

Direct quotation: “visible kingdom of grace.”  
Paraphrase: Christ erected the visible church for gathering and perfecting the saints; it is His visible kingdom of grace and is one across all ages.

**Refs:** BCO 1-2

**Summary:** The church is Christ’s visible kingdom of grace, one in all ages.

### bco-comp-006. Who belongs to the visible church catholic?

Paraphrase: All persons in every nation who profess faith in the Lord Jesus Christ and promise submission to His laws, together with their children.

**Refs:** BCO 1-3, BCO 2-1

**Summary:** Professing believers and their children.

### bco-comp-007. What officers administer the church’s powers?

Paraphrase: Teaching elders, ruling elders, and deacons administer the church’s powers according to Scripture.

**Refs:** BCO 1-4, BCO 7-2

**Summary:** The ordinary officers are elders and deacons; elders include teaching and ruling elders.

### bco-comp-008. Why are Presbyterian courts connectional rather than independent?

Paraphrase: Ecclesiastical jurisdiction is a joint power exercised by presbyters in courts. Courts may oversee one or many churches, yet they stand in mutual relation to express the unity of the church.

**Refs:** BCO 1-5, BCO 11-4

**Summary:** Church courts are mutually related organs of one church, not independent tribunals.

### bco-comp-009. Is Presbyterian polity essential to the existence of the church?

Paraphrase: No. BCO says presbytery is necessary to the perfection of the visible church’s order, but not essential to its existence.

**Refs:** BCO 1-7

**Summary:** Presbyterian order perfects church order but is not of the essence of being a true church.

### bco-comp-010. How should the PCA recognize other Christian denominations?

Paraphrase: Divisions obscure visible unity but do not destroy it. Churches maintaining Word and Sacraments in fundamental integrity are recognized as true branches of Christ’s church.

**Refs:** BCO 2-2

**Summary:** True branches maintain Word and Sacraments in fundamental integrity.

### bco-comp-011. What is the twofold distinction in ecclesiastical power?

Direct quotation: “power of order.”  
Paraphrase: The power of order is exercised severally by officers in preaching, sacraments, reproof, visitation, and comfort. The power of jurisdiction is exercised jointly in church courts.

**Refs:** BCO 3-2

**Summary:** Order: officer acts severally. Jurisdiction: courts act jointly.

### bco-comp-012. What are the church’s sole functions as distinct from the civil commonwealth?

Paraphrase: To proclaim, administer, and enforce the law of Christ revealed in Scripture.

**Refs:** BCO 3-3

**Summary:** Proclaim, administer, and enforce Christ’s revealed law.

### bco-comp-013. How does BCO 3 distinguish church power from state power?

Paraphrase: Church power is exclusively spiritual; civil power includes force. The church receives its constitution from divine revelation; the state’s constitution is determined by reason and providence.

**Refs:** BCO 3-4

**Summary:** Church: spiritual. State: includes force.

### bco-comp-014. What is a particular church?

Paraphrase: A body of professing Christians and their children associated for worship and godly living, according to Scripture, under Christ’s lawful government.

**Refs:** BCO 4-1

**Summary:** A local congregation ordered for worship, godly living, and Christ’s government.

### bco-comp-015. Where is the jurisdiction of a particular church lodged?

Paraphrase: In the Session, consisting of the pastor or pastors, associate pastor(s), and ruling elders.

**Refs:** BCO 4-3, BCO 12-1

**Summary:** Local jurisdiction is lodged in the Session.

### bco-comp-016. What ordinances does BCO 4 list as established by Christ in His church?

Paraphrase: Prayer, singing praise, Scripture reading and preaching, Baptism, the Lord’s Supper, fasting and thanksgiving, catechizing, offerings for mercy and pious uses, discipline, vows, and ordination.

**Refs:** BCO 4-4

**Summary:** BCO 4-4 is the compact map of ordinary church ordinances.

## BCO Membership, Mission Churches & Officers

### bco-comp-017. What distinguishes a mission church from a particular church?

Paraphrase: A mission church is like a particular church in its gathered life, but it has no permanent governing body and is temporarily governed or supervised by Presbytery, a mother Session, an evangelist, or a commission.

**Refs:** BCO 5-1, BCO 5-3

**Summary:** Mission churches lack a permanent governing body and aim toward organization.

### bco-comp-018. Who ordinarily establishes mission churches?

Paraphrase: Presbyteries ordinarily establish mission churches within their bounds, whether on their own initiative, through a Session’s initiative, or in response to a petitioning group.

**Refs:** BCO 5-2

**Summary:** Ordinarily, Presbytery establishes the mission church.

### bco-comp-019. What temporary governments may Presbytery provide for a mission church?

Paraphrase: Presbytery may appoint an evangelist, arrange a mother-daughter relationship with a Session, or appoint a commission to serve as temporary Session.

**Refs:** BCO 5-3

**Summary:** Evangelist, mother Session, or temporary-session commission.

### bco-comp-020. What steps organize a mission church as a particular church?

Paraphrase: The temporary government oversees officer nomination and election, the members petition Presbytery, Presbytery appoints an organizing commission, and the commission ordains/installs officers and declares the church organized.

**Refs:** BCO 5-9

**Summary:** Petition, Presbytery approval, organizing commission, officers, covenant, declaration.

### bco-comp-021. What are non-communing members?

Paraphrase: The baptized children of believers, members by covenant and birthright, entitled to Baptism and to pastoral oversight, instruction, and government of the church.

**Refs:** BCO 6-1

**Summary:** Covenant children are non-communing members.

### bco-comp-022. What are communing members?

Paraphrase: Those who have professed faith in Christ, have been baptized, and have been admitted by the Session to the Lord’s Table.

**Refs:** BCO 6-2

**Summary:** Profession, Baptism, and admission to the Table.

### bco-comp-023. Who is entitled to all rights and privileges of the church?

Paraphrase: Only those who have professed faith, been baptized, and been admitted by the Session to the Lord’s Table.

**Refs:** BCO 6-4

**Summary:** Communing members have all rights and privileges.

### bco-comp-024. What ordinary and perpetual offices does the BCO recognize?

Paraphrase: Elders and deacons. Within the eldership are teaching elders and ruling elders.

**Refs:** BCO 7-2

**Summary:** Two classes of ordinary office: elders and deacons.

### bco-comp-025. What is the basic difference between elder and deacon?

Paraphrase: Elders jointly govern and spiritually oversee the church, including teaching. Deacons serve the physical and spiritual needs of the people and do not exercise rule.

**Refs:** BCO 7-2, BCO 9-1

**Summary:** Elders rule and oversee; deacons serve mercy and practical needs.

### bco-comp-026. What titles should not be given to unordained people?

Paraphrase: Unordained people should not be referred to by titles of ordained offices such as pastor/elder or deacon.

**Refs:** BCO 7-3

**Summary:** Do not title unordained persons as ordained officers.

### bco-comp-027. What qualifications does BCO 8 require of an elder?

Paraphrase: An elder should be competent in learning, blameless in life, sound in faith, apt to teach, sober and holy, faithful in chastity and sexual purity, ruling his own house well, and well regarded outside the church.

**Refs:** BCO 8-2

**Summary:** Learning, life, doctrine, teaching aptitude, household, reputation, purity.

### bco-comp-028. What are the shared duties of elders?

Paraphrase: Elders watch over doctrine and morals, exercise government and discipline, visit and instruct, comfort mourners, guard the children of the church, evangelize, disciple, show hospitality, and pray with and for the people.

**Refs:** BCO 8-3

**Summary:** Elders shepherd doctrine, morals, discipline, visitation, instruction, prayer, and example.

### bco-comp-029. What belongs especially to the teaching elder?

Paraphrase: In addition to shared elder duties, the teaching elder reads, expounds, and preaches the Word and administers the Sacraments.

**Refs:** BCO 8-5

**Summary:** Teaching elders preach the Word and administer sacraments.

### bco-comp-030. What is the parity of teaching and ruling elders?

Paraphrase: Both are elders of one class of office. Ruling elders possess the same authority and eligibility in church courts as teaching elders, though their functions differ.

**Refs:** BCO 8-10

**Summary:** Same office and court authority; different functions.

### bco-comp-031. What may a Presbytery commission an evangelist to do?

Paraphrase: In mission settings, a teaching elder evangelist may be commissioned to preach, administer sacraments, receive and dismiss mission-church members, train potential officers, and in extraordinary cases examine, ordain, install officers, and organize churches.

**Refs:** BCO 8-6

**Summary:** Evangelists may receive extraordinary delegated powers for mission-church work.

### bco-comp-032. What is the character of the deacon’s office?

Direct quotation: “sympathy and service.”  
Paraphrase: It is an ordinary, perpetual office of sympathy and service, reflecting the communion of saints and mutual help in need.

**Refs:** BCO 9-1

**Summary:** Deacon = sympathy, service, mercy.

### bco-comp-033. What are the chief duties of deacons?

Paraphrase: To minister to the needy, sick, friendless, and distressed; promote liberality; collect and distribute gifts; and care for church property under Session oversight.

**Refs:** BCO 9-2

**Summary:** Mercy, liberality, collections, distribution, and property care.

### bco-comp-034. How are deacons organized in a particular church?

Paraphrase: As a Board of Deacons, with the pastor as advisory member. The Board elects a chairman and secretary, keeps records, manages funds assigned to it, and submits minutes to the Session.

**Refs:** BCO 9-4

**Summary:** A local diaconate is organized as a Board under Session oversight.

### bco-comp-035. May non-officers assist the deacons?

Paraphrase: Yes. The Session may appoint godly men and women to assist the deacons in mercy work; these assistants are not church officers and are not ordained.

**Refs:** BCO 9-7

**Summary:** Deacon assistants may be appointed but are not ordained officers.

## BCO Courts: Session, Presbytery, General Assembly & Commissions

### bco-comp-036. Name the regular courts of the PCA.

Paraphrase: The Session, the Presbytery, and the General Assembly.

**Refs:** BCO 10-2

**Summary:** Session, Presbytery, General Assembly.

### bco-comp-037. What officers must each church court have?

Paraphrase: A moderator and clerk. The pastor ordinarily moderates the Session; Presbyteries and General Assembly elect moderators as provided.

**Refs:** BCO 10-3, BCO 10-4

**Summary:** Courts have moderators and clerks.

### bco-comp-038. What is the jurisdiction of church courts?

Paraphrase: Jurisdiction is moral and spiritual, not civil. It concerns doctrine, order, worship, discipline, and the administration necessary to give effect to those powers.

**Refs:** BCO 11-1, BCO 11-2

**Summary:** Church courts exercise spiritual, not civil, jurisdiction.

### bco-comp-039. How do the three courts differ in sphere?

Direct quotation: “regular gradation.”  
Paraphrase: Session governs a single church; Presbytery governs what is common to ministers, Sessions, and churches within a district; General Assembly governs matters concerning the whole church.

**Refs:** BCO 11-4

**Summary:** Local, regional, whole-church spheres.

### bco-comp-040. Who composes the Session?

Paraphrase: The pastor, any associate pastor(s), and the ruling elders of the church. Assistant pastors may be invited to participate without vote.

**Refs:** BCO 12-1

**Summary:** Pastor/associate pastors plus ruling elders; assistants no vote.

### bco-comp-041. What is the Session quorum when a church has a pastor?

Paraphrase: If there are four or more ruling elders: pastor plus two ruling elders. If fewer than four: pastor plus one ruling elder. A Session may set a larger quorum.

**Refs:** BCO 12-1

**Summary:** With pastor: pastor + two REs if 4+ REs; pastor + one RE if fewer.

### bco-comp-042. What is the Session quorum when a church has no pastor?

Paraphrase: If there are five or more ruling elders, three constitute a quorum; if fewer than five, two. One ruling elder alone is not a Session but should take spiritual oversight and report matters needing court action.

**Refs:** BCO 12-1

**Summary:** No pastor: 3 if 5+ REs; 2 if fewer; one RE is not a Session.

### bco-comp-043. What are some specific powers of the Session?

Paraphrase: The Session receives, dismisses, disciplines, and oversees members; examines, ordains, and installs ruling elders and deacons; reviews deacon records; approves the budget; controls worship and church property uses; calls congregational meetings; and appoints representatives to higher courts.

**Refs:** BCO 12-5

**Summary:** Membership, discipline, officers, worship, budget, property uses, meetings, representatives.

### bco-comp-044. How often must the Session meet and keep records?

Paraphrase: It must hold stated meetings at least quarterly, open and close meetings with prayer, keep accurate minutes, and submit records annually to Presbytery.

**Refs:** BCO 12-6, BCO 12-7, BCO 12-9

**Summary:** At least quarterly; records annually reviewed by Presbytery.

### bco-comp-045. Who composes a Presbytery?

Paraphrase: All teaching elders and churches within its bounds accepted by the Presbytery; when meeting as court, it includes teaching elders and ruling elders elected by Sessions.

**Refs:** BCO 13-1

**Summary:** Regional court of TEs and RE representatives of churches.

### bco-comp-046. What is the ruling elder representation formula for Presbytery?

Paraphrase: Each congregation receives two ruling elder representatives for the first 350 communing members or fraction, plus one additional ruling elder for each additional 500 communicants or fraction.

**Refs:** BCO 13-1

**Summary:** Two REs for first 350; one more per additional 500 or fraction.

### bco-comp-047. What is the quorum of Presbytery?

Paraphrase: Three ministers belonging to the Presbytery and at least three ruling elders. Presbytery may fix a larger quorum.

**Refs:** BCO 13-4

**Summary:** 3 TEs + 3 REs minimum.

### bco-comp-048. What are core powers of Presbytery?

Paraphrase: Presbytery oversees ministers, candidates, Sessions, and churches; examines and receives ministers; licenses, ordains, installs, transfers, judges, and removes teaching elders; organizes and dissolves churches; reviews Session records; resolves references, appeals, and complaints; and promotes mission.

**Refs:** BCO 13-9

**Summary:** Presbytery governs what is common to ministers, Sessions, and churches.

### bco-comp-049. How are ministers transferring from another PCA Presbytery examined?

Paraphrase: They are examined on Christian experience, personal character and family management, and their views in theology, sacraments, and church government; they must state any differences with the Standards.

**Refs:** BCO 13-6

**Summary:** Transfer exams include experience, character/family, theology, sacraments, government, and stated differences.

### bco-comp-050. What is the General Assembly?

Paraphrase: The highest court of the PCA, representing all churches in one body and serving as the bond of union, peace, and correspondence among congregations and courts.

**Refs:** BCO 14-1

**Summary:** The highest court and bond of union among PCA churches.

### bco-comp-051. Who composes the General Assembly?

Paraphrase: All teaching elders in good standing with their Presbyteries and ruling elders elected by Sessions according to the representation formula.

**Refs:** BCO 14-2

**Summary:** TEs in good standing plus RE commissioners from Sessions.

### bco-comp-052. What is the quorum for General Assembly?

Paraphrase: One hundred commissioners, half teaching elders and half ruling elders, representing at least one-third of the Presbyteries.

**Refs:** BCO 14-5

**Summary:** 100 commissioners: 50 TEs, 50 REs, one-third of Presbyteries.

### bco-comp-053. What kinds of business may General Assembly handle?

Paraphrase: Appeals, references, and complaints; doctrinal and disciplinary controversies; review of Presbytery records; measures for church growth; erecting, uniting, and dividing Presbyteries; superintending agencies; suppressing schism; correspondence with other churches; and constitutional amendment proposals.

**Refs:** BCO 14-6

**Summary:** GA handles whole-church doctrine, discipline, review, mission, presbyteries, agencies, correspondence, amendments.

### bco-comp-054. What force do General Assembly actions have?

Paraphrase: Deliverances, resolutions, overtures, and judicial decisions receive due and serious consideration; judicial decisions bind the parties and may be appealed to for principles decided in similar cases.

**Refs:** BCO 14-7

**Summary:** GA actions deserve serious consideration; judicial decisions bind parties.

### bco-comp-055. What is the difference between a committee and a commission?

Paraphrase: A committee examines, considers, and reports. A commission is authorized to deliberate and conclude the business referred to it.

**Refs:** BCO 15-1

**Summary:** Committee reports; commission acts for the court.

### bco-comp-056. What matters may Presbytery commit to commissions?

Paraphrase: Taking testimony in judicial cases, ordaining or installing ministers, visiting disorderly portions of the church, organizing new churches, and other properly referred cases.

**Refs:** BCO 15-2, BCO 15-3

**Summary:** Commissions may act in ordination, installation, testimony, visitation, organization, and judicial matters.

### bco-comp-057. What is the minimum composition of a Presbytery commission?

Paraphrase: At least two teaching elders and two ruling elders. Ordination, installation, or judicial commissions require a quorum not less than two teaching elders and two ruling elders.

**Refs:** BCO 15-2

**Summary:** At least 2 TEs + 2 REs; judicial/ordination quorum at least the same.

### bco-comp-058. What is the Standing Judicial Commission?

Paraphrase: A permanent General Assembly commission of twenty-four members, equal numbers of teaching and ruling elders by classes, to which GA commits judicial matters governed by the Rules of Discipline, except annual Presbytery-record review.

**Refs:** BCO 15-4

**Summary:** SJC handles GA judicial cases under BCO 15.

## BCO Vocation, Candidates, Licensure, Ordination & Congregational Action

### bco-comp-059. What is ordinary vocation to office?

Paraphrase: God’s calling by the Spirit through an inward testimony of conscience, the manifest approbation of God’s people, and the concurring judgment of a lawful church court.

**Refs:** BCO 16-1

**Summary:** Inward call, church recognition, court judgment.

### bco-comp-060. May a man be placed in office without election by the church?

Paraphrase: No. Ordinary vocation to office includes election by the body where the officer will serve, with court judgment and ordination/installation as applicable.

**Refs:** BCO 16-2, BCO 17-1

**Summary:** Election and court approval are ordinary parts of calling.

### bco-comp-061. What is ordination?

Paraphrase: The authoritative admission of a man to church office by prayer and the laying on of hands of a court, following election, examination, and approval.

**Refs:** BCO 17-1, BCO 17-2

**Summary:** Ordination authoritatively admits to office after testing and election/call.

### bco-comp-062. Is ordination repeated when an officer changes work?

Paraphrase: No. Ordination is to office and is not repeated; installation places an already ordained officer into a particular charge.

**Refs:** BCO 17-2, BCO 21, BCO 24

**Summary:** Ordination once; installation for a specific charge.

### bco-comp-063. Who may become a candidate for the gospel ministry?

Paraphrase: A communing member who believes himself called to preach and submits to Presbytery’s care, guidance, study, and practical training.

**Refs:** BCO 18-1

**Summary:** A candidate is a communing member under Presbytery care for ministry preparation.

### bco-comp-064. What is ordinarily required before a man comes under care as a candidate?

Paraphrase: He should be a communicant member for at least six months, receive Session endorsement, apply to Presbytery in time, appear before Presbytery, and be examined on experimental religion and motives.

**Refs:** BCO 18-2, BCO 18-3

**Summary:** Membership, Session endorsement, application, personal appearance, examination.

### bco-comp-065. What is licensure?

Paraphrase: Presbytery’s permission for a candidate to preach the gospel regularly in PCA pulpits under its jurisdiction as a probationary step toward ordination.

**Refs:** BCO 19-1

**Summary:** Licensure authorizes regular preaching before ordination.

### bco-comp-066. What examinations are required for licensure?

Paraphrase: Christian experience and inward call; theology; English Bible; the BCO; oral examination in the same areas; plus a written and delivered sermon.

**Refs:** BCO 19-2

**Summary:** Experience/call, theology, Bible, BCO, oral exam, sermon.

### bco-comp-067. What is internship in the BCO?

Paraphrase: A period for trial and development of ministerial gifts before ordination. It must be at least one year and should involve the full scope of regular ministerial duties as Presbytery determines.

**Refs:** BCO 19-7

**Summary:** At least one year testing gifts and duties.

### bco-comp-068. Who may call a pastor?

Paraphrase: A congregation, acting in a properly called congregational meeting, elects a pastor; Presbytery must approve and install the pastoral relationship.

**Refs:** BCO 20, BCO 21

**Summary:** Congregation elects; Presbytery approves and installs.

### bco-comp-069. What is a pulpit committee/search committee?

Paraphrase: The congregation may elect a committee to seek a pastor and recommend a candidate, but the call itself belongs to the congregation and must be approved by Presbytery.

**Refs:** BCO 20-2, BCO 20-3

**Summary:** Search committees recommend; congregations vote; Presbytery approves.

### bco-comp-070. What votes are required to elect a pastor?

Paraphrase: The congregation votes by ballot. A majority is ordinarily required, unless the congregation has by rule required a larger majority.

**Refs:** BCO 20-3

**Summary:** Pastoral election is by congregational ballot, ordinarily majority.

### bco-comp-071. What trials are required for ordination to the gospel ministry?

Paraphrase: Presbytery examines Christian experience and call, theology, sacraments, church government, Bible content, church history, PCA history, original languages, and requires sermon and papers as specified.

**Refs:** BCO 21-4

**Summary:** Ordination trials cover experience, doctrine, Bible, sacraments, government, history, languages, sermon/papers.

### bco-comp-072. How does Presbytery evaluate a candidate’s differences with the Westminster Standards?

Paraphrase: The candidate states each difference. Presbytery judges whether it is merely semantic, more than semantic but not contrary to fundamentals, or out of accord with a fundamental of the system.

**Refs:** BCO 21-4.f, BCO 21-4.g

**Summary:** The court, not the candidate alone, judges stated differences.

### bco-comp-073. What are the ordination vows for a teaching elder about Scripture and Standards?

Paraphrase: He affirms Scripture as inerrant Word of God, sincerely receives and adopts the Westminster Standards as containing the system of doctrine taught in Scripture, and approves PCA government and discipline.

**Refs:** BCO 21-5

**Summary:** TE vows bind him to Scripture, Westminster Standards, and PCA polity.

### bco-comp-074. What vows does a teaching elder make about ministry conduct?

Paraphrase: He promises subjection to his brethren, zeal for gospel truth and church purity/peace, faithful discharge of duties, and pastoral care over the charge if installed.

**Refs:** BCO 21-5

**Summary:** Submission, zeal, faithfulness, and pastoral charge.

### bco-comp-075. What vows does the congregation make to a pastor?

Paraphrase: The congregation receives him as pastor, promises to receive the Word with meekness and love, submit to him in the Lord, encourage him, and provide for his temporal support.

**Refs:** BCO 21-10

**Summary:** Receive, heed, submit in the Lord, encourage, and support.

### bco-comp-076. How do pastor, associate pastor, and assistant pastor differ?

Paraphrase: A pastor is called by the congregation. An associate pastor is also called by the congregation and is a Session member. An assistant pastor is called by the Session and is not a Session member by that call.

**Refs:** BCO 22-1, BCO 22-2, BCO 22-3

**Summary:** Congregation calls pastor/associate; Session calls assistant.

### bco-comp-077. Who dissolves a pastoral relationship?

Paraphrase: Presbytery dissolves the pastoral relationship, ordinarily after the pastor, congregation, or both seek dissolution and the parties have opportunity to be heard.

**Refs:** BCO 23

**Summary:** Presbytery has the final action on dissolution.

### bco-comp-078. How are ruling elders and deacons nominated and elected?

Paraphrase: The Session gives at least one month’s public notice, receives nominations, examines nominees, presents approved nominees, and the congregation elects by majority vote of those present unless the congregation has set a higher threshold.

**Refs:** BCO 24-1, BCO 24-3, BCO 24-4

**Summary:** Notice, nominations, Session examination, congregational election.

### bco-comp-079. What does the Session examine in ruling elder and deacon nominees?

Paraphrase: Christian experience, especially personal character; knowledge of doctrine, government, and discipline; the duties of the office; and willingness to assent to ordination questions.

**Refs:** BCO 24-1

**Summary:** Character, doctrine, polity, duties, vows.

### bco-comp-080. What vows do ruling elders and deacons make?

Paraphrase: They affirm Scripture, receive the Westminster Standards, approve PCA government and discipline, accept office, promise faithful performance, and promise subjection to their brethren in the Lord.

**Refs:** BCO 24-6

**Summary:** RE/deacon vows parallel TE subscription and office faithfulness.

### bco-comp-081. Who may vote in congregational meetings?

Paraphrase: Communing members in good and regular standing are entitled to vote in congregational meetings.

**Refs:** BCO 25-1

**Summary:** Communing members vote.

### bco-comp-082. What notice and business limits apply to congregational meetings?

Paraphrase: The Session calls congregational meetings and gives at least one week’s public notice. No business may be transacted except what is stated in the notice.

**Refs:** BCO 25-2

**Summary:** One week notice; business limited to the notice.

### bco-comp-083. Who owns local church property?

Paraphrase: The particular church, through its corporation/trustees or proper representatives, holds sole title to its property; higher courts receive property only by free and voluntary action.

**Refs:** BCO 25-8

**Summary:** Local church owns its property.

### bco-comp-084. How is the BCO amended?

Paraphrase: A majority vote at one General Assembly recommends the amendment, two-thirds of Presbyteries advise and consent, and a subsequent General Assembly approves and enacts by majority vote.

**Refs:** BCO 26-2

**Summary:** GA majority → 2/3 Presbyteries → next GA majority.

### bco-comp-085. How are the Westminster Standards amended?

Paraphrase: Three-fourths of a General Assembly recommends, three-fourths of Presbyteries advise and consent, and a subsequent General Assembly approves and enacts by three-fourths vote.

**Refs:** BCO 26-3

**Summary:** 3/4 GA → 3/4 Presbyteries → next GA 3/4.

## BCO Discipline, Offenses, Censures & Judicial Process

### bco-comp-086. Define discipline in the BCO.

Paraphrase: Discipline is church authority given by Christ to instruct, guide, and promote purity and welfare. It includes broad shepherding government and the narrower technical sense of judicial process.

**Refs:** BCO 27-1

**Summary:** Discipline broadly trains and governs; narrowly, it is judicial process.

### bco-comp-087. Who is subject to church discipline?

Direct quotation: “exercise of authority.”  
Paraphrase: All baptized persons, because they are members of the church, are subject to discipline and entitled to its benefits.

**Refs:** BCO 27-2

**Summary:** All baptized members are under discipline.

### bco-comp-088. What are the ends of discipline?

Paraphrase: The glory of God, the purity of the church, the keeping and reclaiming of disobedient sinners; judicially, it rebukes offenses, removes scandal, vindicates Christ’s honor, edifies the church, and seeks the offender’s spiritual good.

**Refs:** BCO 27-3

**Summary:** Glory of God, purity of church, reclaiming sinners.

### bco-comp-089. What pastoral spirit should govern discipline?

Paraphrase: Discipline is for building up, not destruction. It should be exercised under mercy, with pastoral instruction and the aim of restoration.

**Refs:** BCO 27-4, BCO 36-5

**Summary:** Discipline is remedial and pastoral, not merely punitive.

### bco-comp-090. What are the ordinary Scriptural steps before court action?

Paraphrase: Instruction in the Word; private admonition; one or more witnesses if rejected; then the church acting through her court if rejection persists.

**Refs:** BCO 27-5

**Summary:** Word, admonition, witnesses, court action.

### bco-comp-091. How should non-communing members be disciplined?

Paraphrase: Primarily through parents, with Session oversight, instruction, catechizing, and pastoral care aimed at bringing covenant children to personal faith and orderly discipleship.

**Refs:** BCO 28-1, BCO 28-3

**Summary:** Parents have primary responsibility, with Session oversight.

### bco-comp-092. What is an offense?

Paraphrase: Anything in doctrine or practice contrary to the Word of God. The BCO distinguishes personal offenses from general offenses and requires careful judgment by the courts.

**Refs:** BCO 29-1

**Summary:** An offense is doctrine or practice contrary to Scripture.

### bco-comp-093. When should courts handle private offenses?

Paraphrase: Private offenses should first be addressed by the personal steps of Matthew 18. A court acts when those steps fail or when scandal and church welfare require formal process.

**Refs:** BCO 29, BCO 31

**Summary:** Private offenses ordinarily start privately before court action.

### bco-comp-094. List the church censures.

Paraphrase: Admonition, suspension from the Sacraments, suspension from office, deposition from office, and excommunication.

**Refs:** BCO 30-1

**Summary:** Admonition, suspension, deposition, excommunication.

### bco-comp-095. What is admonition?

Direct quotation: “judicial process.”  
Paraphrase: A formal reproof by a church court, warning the offender and calling him to repentance.

**Refs:** BCO 30-2, BCO 36

**Summary:** Formal reproof and warning.

### bco-comp-096. What is suspension?

Paraphrase: Temporary exclusion from sacramental privileges, from office, or both, either definite or indefinite as the case requires.

**Refs:** BCO 30-3, BCO 30-4

**Summary:** Temporary exclusion from privilege or office.

### bco-comp-097. What are deposition and excommunication?

Paraphrase: Deposition removes an officer from office. Excommunication excludes an offender from church communion until repentance and restoration.

**Refs:** BCO 30-5, BCO 30-6

**Summary:** Deposition removes office; excommunication excludes from communion.

### bco-comp-098. Who are the parties in a case of process?

Paraphrase: The Presbyterian Church in America is the accuser; the accused is the other party. The court appoints a prosecutor when formal process is instituted.

**Refs:** BCO 31-1, BCO 31-2

**Summary:** In process, the church prosecutes; the accused answers.

### bco-comp-099. What must a court do before formal process?

Paraphrase: It must exercise due diligence and discretion to seek satisfactory explanations concerning reports affecting Christian character. If a strong presumption of guilt arises, the court institutes process.

**Refs:** BCO 31-2

**Summary:** Investigate reports; institute process only on strong presumption of guilt.

### bco-comp-100. What must a charge and specification contain?

Paraphrase: A charge states the alleged offense; specifications give the facts, times, places, and circumstances supporting the charge so the accused can answer.

**Refs:** BCO 32-5

**Summary:** Charge = offense; specifications = facts supporting it.

### bco-comp-101. What rights does the accused have in process?

Paraphrase: The accused must receive proper citation and charges, have time to prepare, may object to court members, may be represented as permitted, may present evidence and witnesses, and may appeal adverse judgment.

**Refs:** BCO 32, BCO 42

**Summary:** Notice, preparation, objections, representation, evidence, appeal.

### bco-comp-102. What happens if an accused person refuses or neglects to appear?

Paraphrase: After proper citation, the court may proceed according to the BCO; persistent refusal may itself affect the case and the court’s handling of discipline.

**Refs:** BCO 32-6, BCO 32-7

**Summary:** Proper citation matters; refusal does not necessarily stop process.

### bco-comp-103. What standard applies to court members in judicial process?

Paraphrase: Members should be impartial. Objections may be made to members, and the court must decide whether they should sit in the case.

**Refs:** BCO 32-14

**Summary:** Judicial fairness includes opportunity to object to partial judges.

### bco-comp-104. What is process before a Session?

Paraphrase: The Session has original jurisdiction over church members. Special rules apply for charges before Sessions and for Presbytery assuming jurisdiction if a Session cannot or will not act properly.

**Refs:** BCO 33-1, BCO 33-2

**Summary:** Session ordinarily tries members of the local church.

### bco-comp-105. Who has original jurisdiction over a teaching elder?

Paraphrase: The Presbytery of which the minister is a member, except where the BCO provides otherwise.

**Refs:** BCO 34-1

**Summary:** Presbytery tries its ministers.

### bco-comp-106. How may a minister be suspended during process?

Paraphrase: Presbytery may place restrictions on a minister when charges or circumstances require it, following BCO provisions for protection of the church and due process.

**Refs:** BCO 34

**Summary:** Ministerial process belongs to Presbytery and may include temporary restrictions.

### bco-comp-107. What kinds of evidence may be used?

Paraphrase: Witness testimony, records, documents, and other admissible evidence under the Rules of Discipline; evidence must be relevant and handled with fairness.

**Refs:** BCO 35

**Summary:** Evidence must be competent, relevant, and fairly received.

### bco-comp-108. How many witnesses are required to establish a charge?

Paraphrase: More than one witness is necessary, though one witness plus corroborating evidence may establish an offense.

**Refs:** BCO 35-3

**Summary:** More than one witness, or one plus corroboration.

### bco-comp-109. What testimony rules protect conscience and truth?

Paraphrase: Witnesses are examined under solemn duty to tell the truth, may be cross-examined, and testimony should be recorded as the court requires.

**Refs:** BCO 35

**Summary:** Witnesses testify solemnly and may be examined and cross-examined.

### bco-comp-110. How should censures be inflicted?

Paraphrase: With prayer, tenderness, solemnity, and a clear statement of the offense and censure, suited to the nature of the offense and the spiritual good of the offender.

**Refs:** BCO 36

**Summary:** Censures should be solemn, tender, and restorative.

### bco-comp-111. How may censure be removed?

Paraphrase: Upon repentance and satisfactory evidence of it, the court that imposed or currently has jurisdiction may remove censure and restore privileges or office as the BCO allows.

**Refs:** BCO 37

**Summary:** Repentance and court action remove censure.

### bco-comp-112. What are cases without process?

Paraphrase: Non-judicial cases such as requests for dismissal, erasure, divestiture without censure, demission, or other matters handled without formal trial when guilt is not being adjudicated.

**Refs:** BCO 38

**Summary:** Some actions affect status without a trial or censure.

### bco-comp-113. What is divestiture without censure?

Paraphrase: Removal from office without disciplinary censure, used when a man is no longer qualified or able to serve though not being punished for an offense.

**Refs:** BCO 38-2, BCO 38-3

**Summary:** Office may be removed without censure in non-punitive cases.

### bco-comp-114. What is erasure or removal from roll?

Paraphrase: A Session may remove names from the roll in specified cases such as prolonged absence or failure to transfer membership, following BCO procedures.

**Refs:** BCO 38-4, BCO 46-2

**Summary:** Some roll removals occur without judicial process.

## BCO Review, Appeals, Complaints & Jurisdiction

### bco-comp-115. What are the main ways lower-court proceedings come before higher courts?

Paraphrase: General review and control, references, appeals, complaints, and certain jurisdictional proceedings.

**Refs:** BCO 39

**Summary:** Records, reference, appeal, complaint, jurisdiction.

### bco-comp-116. What is general review and control?

Paraphrase: A higher court’s ordinary review of the records and proceedings of the lower court next below it, to ensure accurate recording, constitutional regularity, wisdom, equity, and obedience to lawful injunctions.

**Refs:** BCO 40-1, BCO 40-2

**Summary:** Annual record review protects order connectionally.

### bco-comp-117. What may a higher court do if it finds error in lower-court records?

Paraphrase: It may note exceptions, require correction, issue injunctions, or use BCO procedures to redress actions contrary to order.

**Refs:** BCO 40

**Summary:** Review can lead to exceptions, corrections, and redress.

### bco-comp-118. What is a reference?

Paraphrase: A written request by a lower court to a higher court for advice or other action on a matter pending before the lower court.

**Refs:** BCO 41-1

**Summary:** Reference = lower court asks higher court for advice/action.

### bco-comp-119. When is a reference appropriate?

Paraphrase: When a lower court needs guidance because of novelty, difficulty, constitutional importance, or consequences beyond its own sphere.

**Refs:** BCO 41

**Summary:** References seek guidance before final disposition.

### bco-comp-120. What is an appeal?

Paraphrase: The transfer of a judicial case to a higher court after judgment, available to the party against whom the decision was rendered.

**Refs:** BCO 42-1

**Summary:** Appeal = judicial case carried up after judgment.

### bco-comp-121. What are common grounds of appeal?

Paraphrase: Irregularity in proceedings, refusal of reasonable indulgence, receiving improper evidence or rejecting proper evidence, hurrying to decision before all testimony, manifest injustice, or mistake/error in judgment.

**Refs:** BCO 42-3

**Summary:** Appeal grounds challenge procedure, evidence, haste, injustice, or error.

### bco-comp-122. How quickly must notice of appeal be filed?

Paraphrase: Written notice with supporting reasons must be filed with both lower and higher court clerks within thirty days after the meeting of the court.

**Refs:** BCO 42-4

**Summary:** Appeal deadline: 30 days.

### bco-comp-123. What can the higher court do on appeal?

Paraphrase: Affirm, reverse, render the decision that should have been rendered, or remand for a new trial.

**Refs:** BCO 42-9

**Summary:** Affirm, reverse, render, or remand.

### bco-comp-124. What is a complaint?

Paraphrase: A written representation against some act or decision of a church court, available to a communing member in good standing subject to that court, except as limited by judicial-process rules.

**Refs:** BCO 43-1

**Summary:** Complaint = challenge to a court action or decision.

### bco-comp-125. How quickly must a complaint be filed?

Paraphrase: Written notice with supporting reasons must be filed with the clerk of the court complained against within thirty days after the meeting of that court.

**Refs:** BCO 43-2

**Summary:** Complaint deadline: 30 days.

### bco-comp-126. How does complaint differ from appeal?

Paraphrase: Appeal belongs to a party in a judicial case after judgment. Complaint challenges a court’s act or decision outside an appealable judicial judgment, subject to BCO limits.

**Refs:** BCO 42-1, BCO 43-1

**Summary:** Appeal = judicial party after judgment; complaint = court act/decision.

### bco-comp-127. What are dissents, protests, and objections?

Paraphrase: Ways members of a court record disagreement or objection to an action. Dissent records disagreement; protest records disagreement with reasons; objection may be entered to preserve a procedural or substantive objection.

**Refs:** BCO 45

**Summary:** Dissent/protest/objection preserve disagreement in the record.

### bco-comp-128. What does BCO jurisdiction cover after someone is dismissed to another church?

Paraphrase: A dismissed member remains under the jurisdiction of the dismissing Session until he forms a regular connection with the receiving church.

**Refs:** BCO 46-3

**Summary:** Jurisdiction continues until the transfer is completed.

### bco-comp-129. What is an associate member?

Paraphrase: A believer temporarily residing away from his permanent home who joins a PCA church without ceasing to be a communicant member of the home church; he has privileges except voting and holding office there.

**Refs:** BCO 46-4

**Summary:** Temporary member with privileges except vote/office.

### bco-comp-130. How long is a certificate of dismission valid as testimony of good standing?

Paraphrase: Not longer than one year unless earlier presentation is hindered by providential cause; it testifies only to the person’s standing when leaving the bounds.

**Refs:** BCO 46-7

**Summary:** Dismissal certificates generally expire after one year.

### bco-comp-131. What happens when Presbytery dismisses a minister, licentiate, or candidate?

Paraphrase: The certificate names the receiving Presbytery, and the person remains under the dismissing Presbytery’s jurisdiction until received by the other.

**Refs:** BCO 46-6

**Summary:** Presbytery jurisdiction continues until reception.

## BCO Directory for Worship: Principles, Lord’s Day & Ordinary Worship

### bco-comp-132. What is the constitutional status of the Directory for Worship?

Paraphrase: The Directory is an approved guide to be taken seriously as the mind of the church, but not obligatory in all parts. BCO 56, 57, 58, and 59-3 have full constitutional authority.

**Refs:** BCO Directory for Worship Preface

**Summary:** Directory is a serious guide; 56, 57, 58, and 59-3 are constitutional.

### bco-comp-133. What is the source of the principles of public worship?

Paraphrase: The Holy Scriptures, the only infallible rule of faith and practice. Worship principles must be derived from the Bible.

**Refs:** BCO 47-1

**Summary:** Worship is governed by Scripture.

### bco-comp-134. What are the ordinary elements of public worship?

Paraphrase: Prayer, praise, reading Scripture, preaching the Word, sacraments, offerings, confession of faith, fasting/thanksgiving when appointed, and related ordinances under Session oversight.

**Refs:** BCO 47, BCO 4-4

**Summary:** Word, prayer, praise, sacraments, offerings, confession, and appointed occasions.

### bco-comp-135. Who has oversight of the time, place, music, and order of worship in a local church?

Paraphrase: The Session exercises authority over worship services, the preaching and sacraments, church music, and use of church property.

**Refs:** BCO 12-5.e, BCO 47

**Summary:** The Session oversees local worship.

### bco-comp-136. How does BCO 48 describe the Lord’s Day?

Paraphrase: The Lord’s Day is to be sanctified by public and private worship, works of necessity and mercy, and resting from worldly employments and recreations inconsistent with holy worship.

**Refs:** BCO 48

**Summary:** Lord’s Day: worship, rest, necessity, mercy.

### bco-comp-137. What general principle governs the ordering of public worship?

Paraphrase: Worship should be ordered according to Scripture, for edification, reverence, understanding, and active congregational participation.

**Refs:** BCO 49

**Summary:** Order serves Scriptural worship and edification.

### bco-comp-138. Who may read Scripture publicly in worship?

Paraphrase: The public reading of Scripture is a worship element under church oversight; ordinarily it should be done by those appointed by the Session in good order.

**Refs:** BCO 50, BCO 12-5.e

**Summary:** Scripture reading is an appointed element under Session oversight.

### bco-comp-139. What does the BCO teach about singing?

Paraphrase: The congregation should sing psalms and hymns with understanding, reverence, and grace in the heart; the Session oversees the singing in public worship.

**Refs:** BCO 51, BCO 12-5.e

**Summary:** Congregational singing is under Session oversight and should edify.

### bco-comp-140. What should public prayer include?

Paraphrase: Adoration, confession, thanksgiving, supplication, intercession, and petitions suited to the needs of the church and world, offered through Christ with reverence and faith.

**Refs:** BCO 52

**Summary:** Public prayer includes praise, confession, thanks, petitions, and intercession.

### bco-comp-141. What is the place of preaching in worship?

Paraphrase: Preaching is a chief means of grace. The preacher should explain and apply Scripture faithfully, plainly, and pastorally for conversion and edification.

**Refs:** BCO 53

**Summary:** Preaching explains and applies Scripture for conversion and edification.

### bco-comp-142. Who may preach in PCA worship?

Paraphrase: The Session must ensure the Word is preached only by men sufficiently qualified under the BCO and Scripture.

**Refs:** BCO 12-5.e, BCO 53-2

**Summary:** Session guards the pulpit.

### bco-comp-143. How should offerings be understood in worship?

Paraphrase: Offerings are acts of worship and mercy, given for the church’s work, relief of the poor, and other pious uses, not merely administrative fundraising.

**Refs:** BCO 54, BCO 4-4

**Summary:** Offerings are worship and service.

### bco-comp-144. Why does BCO include confessing the faith in worship?

Paraphrase: Public confession of the church’s faith strengthens unity, teaches doctrine, and lets the congregation jointly profess the truth it believes.

**Refs:** BCO 55

**Summary:** Confession of faith publicly teaches and unites the church.

### bco-comp-145. What principle should govern worship forms not specifically prescribed?

Paraphrase: Circumstances of worship should be ordered by Christian prudence according to the general rules of the Word, always serving reverence, edification, and decency.

**Refs:** BCO 47, WCF 1.6

**Summary:** Circumstances must serve Scriptural worship, not human invention.

### bco-comp-146. What pastoral mistake should be avoided in studying the Directory for Worship?

Paraphrase: Treating it either as optional fluff or as mechanical rubrics. It is a serious guide to wise Presbyterian worship; some chapters have full constitutional force.

**Refs:** BCO Directory for Worship Preface

**Summary:** Take the Directory seriously, while noting its constitutional distinctions.

## BCO Directory for Worship: Sacraments, Marriage & Pastoral Offices

### bco-comp-147. Who may administer Baptism?

Paraphrase: A minister of the Word lawfully called to administer the sacraments; Baptism is administered under church authority, ordinarily in the presence of the congregation.

**Refs:** BCO 56, BCO 8-5

**Summary:** Teaching elders administer sacraments.

### bco-comp-148. Who should receive Baptism?

Paraphrase: Believers not previously baptized, and the infant children of one or both believing parents, according to the covenant promise and PCA doctrine.

**Refs:** BCO 56, BCO 6-1

**Summary:** Baptize professing believers and covenant children.

### bco-comp-149. What questions are asked of parents at an infant Baptism?

Paraphrase: In paraphrase: they acknowledge the child’s need of Christ, claim God’s covenant promises, dedicate the child to God, and promise to raise the child in the nurture and admonition of the Lord.

**Refs:** BCO 56-5

**Summary:** Parents profess covenant faith and promise Christian nurture.

### bco-comp-150. What vow does the congregation make at an infant Baptism?

Paraphrase: The congregation promises to assist the parents in the Christian nurture of the child.

**Refs:** BCO 56-5

**Summary:** The church shares responsibility for covenant nurture.

### bco-comp-151. How are persons admitted to sealing ordinances?

Paraphrase: By Session examination and admission. Those received into communicant membership make profession of faith and take membership vows before being admitted to the Lord’s Table.

**Refs:** BCO 57

**Summary:** Session admits persons to the sacraments.

### bco-comp-152. Summarize the five membership vows.

Paraphrase: The person acknowledges sin and need of God’s mercy, trusts Christ alone for salvation, resolves by the Spirit to live as a follower of Christ, promises to support the church’s worship and work, and submits to church government and discipline while seeking purity and peace.

**Refs:** BCO 57-5

**Summary:** Sin, Christ, obedience, support, submission/purity/peace.

### bco-comp-153. How may members be received?

Paraphrase: By profession of faith, reaffirmation of faith, letter of transfer, or other proper Session action according to the person’s baptism and church-standing situation.

**Refs:** BCO 57

**Summary:** Profession, reaffirmation, transfer, and related Session actions.

### bco-comp-154. Who should be admitted to the Lord’s Supper?

Paraphrase: The ignorant and scandalous are not to be admitted. At the Session’s discretion, the minister may invite either communicants in good standing in evangelical churches who profess the true religion, or those approved by the Session.

**Refs:** BCO 58, BCO 6-2, BCO 6-4

**Summary:** Not the ignorant or scandalous; Session governs the invitation practice.

### bco-comp-155. What warnings should attend the Lord’s Supper?

Paraphrase: The minister should fence the Table: inviting worthy communicants, warning the ignorant, scandalous, and impenitent not to partake, and directing all to self-examination and faith in Christ.

**Refs:** BCO 58

**Summary:** Fence the Table with invitation, warning, and gospel direction.

### bco-comp-156. What does the BCO say about frequency of the Lord’s Supper?

Paraphrase: The Session determines frequency, but the sacrament should be administered often enough to serve the congregation’s edification and the church’s doctrine of the means of grace.

**Refs:** BCO 58, BCO 12-5.e

**Summary:** Session determines frequency for edification.

### bco-comp-157. What is marriage according to BCO 59-3?

Paraphrase: Marriage is between one man and one woman, and this provision has full constitutional authority in the PCA.

**Refs:** BCO 59-3, BCO Directory for Worship Preface

**Summary:** BCO 59-3 constitutionally defines marriage as man and woman.

### bco-comp-158. What pastoral cautions govern solemnizing marriage?

Paraphrase: The minister should ensure the couple may lawfully marry, instruct them in the nature and duties of marriage, and avoid participating in unions contrary to Scripture and the PCA Constitution.

**Refs:** BCO 59

**Summary:** Marriage requires lawful eligibility and biblical instruction.

### bco-comp-159. What is the aim of visitation of the sick?

Paraphrase: Pastoral comfort, prayer, Scripture, spiritual counsel, and preparation for suffering or death in faith, repentance, and hope in Christ.

**Refs:** BCO 60

**Summary:** Visit the sick with Word, prayer, comfort, counsel, and hope.

### bco-comp-160. How should the burial of the dead be conducted?

Paraphrase: With simplicity, dignity, Scripture, prayer, and Christian hope, avoiding superstition and directing mourners to the resurrection and judgment.

**Refs:** BCO 61

**Summary:** Christian burial is sober, hopeful, and Word-centered.

### bco-comp-161. What are days of fasting and thanksgiving?

Paraphrase: Special occasions appointed for solemn humiliation, prayer, and repentance, or for grateful acknowledgment of God’s mercies.

**Refs:** BCO 62

**Summary:** Fasting humbles; thanksgiving gratefully acknowledges mercies.

### bco-comp-162. Who may appoint days of fasting or thanksgiving?

Paraphrase: Church courts may appoint them for their own bounds; civil authorities may appoint public occasions, but the church observes them as acts of religious worship under God.

**Refs:** BCO 62

**Summary:** Courts may appoint church occasions; civil occasions are observed religiously under God.

### bco-comp-163. What does the BCO teach about Christian life in the home?

Paraphrase: The home is a primary sphere of discipleship: worship, instruction, catechizing, prayer, discipline, and godly example should nurture covenant children and households in the faith.

**Refs:** BCO 63, BCO 28

**Summary:** Home discipleship is essential to church discipline and nurture.

### bco-comp-164. Why are BCO 56-58 especially important for ordination study?

Paraphrase: They have full constitutional authority and govern Baptism, admission to sealing ordinances, and the Lord’s Supper; candidates should know both the doctrine and the procedural details.

**Refs:** BCO Directory for Worship Preface, BCO 56, BCO 57, BCO 58

**Summary:** Baptism, admission, and the Supper are constitutionally binding chapters.

### bco-comp-165. How do BCO 56-58 connect membership and sacraments?

Paraphrase: Baptism marks covenant membership, Session examination admits professing believers to communicant privileges, and the Lord’s Supper is administered to those admitted and not barred by discipline.

**Refs:** BCO 56, BCO 57, BCO 58, BCO 6

**Summary:** Baptism, profession, Session admission, and discipline structure sacramental access.
